#!/usr/bin/env python


#YOU USE SPACE TO TAKE PHOTOS

import cv2
import os
from datetime import datetime

stream = cv2.VideoCapture(0)
if not stream.isOpened():
    exit()

cv2.namedWindow("Webcam", cv2.WINDOW_NORMAL)
cv2.resizeWindow("Webcam", 1000, 800)

# folder to save photos
save_folder = os.path.expanduser("~/Pictures/Webcam")
os.makedirs(save_folder, exist_ok=True)

print("Press SPACE to take a photo, Q to quit")

while True:
    ret, frame = stream.read()
    if not ret:
        break

    cv2.imshow("Webcam", frame)

    key = cv2.waitKey(1) & 0xFF

    if key == ord(' '):
        filename = datetime.now().strftime("%Y-%m-%d_%H-%M-%S") + ".jpg"
        filepath = os.path.join(save_folder, filename)
        cv2.imwrite(filepath, frame)
        print(f"Photo saved: {filepath}")

    
    if key == ord('q'):
        break

stream.release()
cv2.destroyAllWindows()